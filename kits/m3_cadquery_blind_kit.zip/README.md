# M3-CRETE M3-2 - CadQuery Blind Kit (ARB benchmark)

A **blind** benchmark kit: authored parts + the task, with **no reference solution**.

## Contents
- `CADQUERY_DRIVER_BRIEF.md` - task, fixture constraints, how to drive CadQuery.
- `kit/` - 14 authored STEP part files (the only geometry inputs). Repeated parts
  are one file each: e.g. the **single NEMA 23 motor** (`M3_NEMA23_motor.step`) is
  placed seven times, oriented by you - one motor SKU, not seven pre-rotated files.
- `reference_overview.png` (3/4, all components visible) + `reference_front.png`,
  `reference_top.png`, `reference_side.png` - rendered views of the assembled target
  to build toward (arrangement only; no dimensions, no spec, no answer key).

## How to run
1. Fresh agent session (Claude Code, or GPT/Codex - the model under test), started
   IN THIS FOLDER (not a CADCLAW checkout, no AGENTS.md, no project memory).
   `pip install cadquery`.
2. Paste the `=== BEGIN === ... === END ===` block of CADQUERY_DRIVER_BRIEF.md as the only input.
3. The driver writes `cadquery_native_export.step` + `run_log.yaml` here.
4. Hand `cadquery_native_export.step` back to the CADCLAW grader (same gates as the Fusion track).

Fairness: this kit intentionally has NO answer key (no spec, transforms, or solution).
The reference images show only the target's arrangement - a picture of the goal, like
a human builder gets. Build only from the brief + kit/ + the reference images.


## Parts — license & attribution

The CAD parts in `kit/` are licensed separately from any code (full text: LICENSE.md in this kit):

- **OpenBuilds-derived** (V-Slot® / C-Beam® rails, gantry plates, Solid V Wheel, GT2 pulley,
  smooth idler, NEMA 23, GT2 belts, VS_Belt_Pinion): © OpenBuilds LLC, licensed
  **CC BY-SA 4.0** (https://creativecommons.org/licenses/by-sa/4.0/). Source: https://openbuilds.com/.
  V-Slot®, C-Beam®, V-Wheel® are OpenBuilds trademarks; use here refers to the published
  geometric profiles and implies no endorsement. Redistribute these files under CC BY-SA 4.0.
- **Sunnyday-authored** (`M3_6mm_frame_shim_4080`, `ZPMM_6p1_motor_mount_spacer`):
  © Sunnyday Technologies, MIT.

# M3-CRETE M3-2 - Fusion Blind Kit (ARB benchmark)

A **blind** benchmark kit: authored parts + the task, with **no reference solution**.
Same kit + task as the CadQuery track; only the "how to drive" stub differs.

## Contents
- `FUSION_DRIVER_BRIEF.md` - task, fixture constraints, how to drive Fusion via the MCP.
- `kit/` - 14 authored STEP part files (the only geometry inputs). Repeated parts
  are one file each: e.g. the **single NEMA 23 motor** (`M3_NEMA23_motor.step`) is
  placed seven times, oriented by you - one motor SKU, not seven pre-rotated files.
- `reference_overview.png` (3/4, all components visible) + `reference_front.png`,
  `reference_top.png`, `reference_side.png` - rendered views of the assembled target
  to build toward (arrangement only; no dimensions, no spec, no answer key).

## How to run
1. Fresh Claude session with the Autodesk Fusion MCP, started IN THIS FOLDER
   (not a CADCLAW checkout, no AGENTS.md, no project memory), with Fusion open.
2. Paste the `=== BEGIN === ... === END ===` block of FUSION_DRIVER_BRIEF.md as the only input.
3. The driver imports the kit/ STEPs into a new Fusion design, assembles, and
   exports `fusion_native_export.step` + writes `run_log.yaml` here.
4. Hand `fusion_native_export.step` back to the CADCLAW grader (same gates as the CadQuery track).

Fairness: this kit intentionally has NO answer key (no spec, transforms, or solution).
The reference images show only the target's arrangement. Build only from the brief +
kit/ + the reference images; do not pull parts from any Fusion cloud project.
